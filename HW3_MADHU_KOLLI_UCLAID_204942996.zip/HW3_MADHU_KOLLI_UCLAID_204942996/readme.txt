Included files are LaTex pdf for HW3 .HW3.py that needs to be run on a GPU. I ran this on google colab and the whole run completes in less than 1 hour.

Key Results:
Epoch	FCC(With ReLu)	FCC(W/o ReLu)	CNN FCC with ReLu	CNN FCC w/o ReLu
1	2.1290	    	1.9841		1.8898			1.9642
2	1.8190		1.9266		1.4867			1.9226
3	1.6919		1.9107		1.2797			1.9129
4	1.6159		1.9079		1.1130			1.9092
5	1.5694		1.9019		0.9874			1.9044
6	1.5266		1.9033		0.8757			1.9016
7	1.4971		1.8998		0.7969			1.8973
8	1.4703		1.8964		0.7306			1.8950
9	1.4497		1.8963		0.6853			1.8948
10	1.4319		1.8977		0.6350			1.8946
	
	54.72%		37.69%		85.87%			36.59%
	Accuracy %			
